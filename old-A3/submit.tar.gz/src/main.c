#define _GNU_SOURCE
#include <pthread.h>

#define USE_AVX512

#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdbool.h>
#include <complex.h>
#include <threads.h>
#include <stdatomic.h>

#ifdef USE_AVX512
#include <immintrin.h>
#endif

static atomic_uchar *row_done;
static atomic_int next_row;   // rows are handed out in order 0, 1, 2, ...

#define cpow(a, b) \
(do { \
    fprintf(stderr, "forbidden :)\n"); \
    exit(EXIT_FAILURE); \
} while(0))

struct cfg {
  int num_threads, lines, degree;
};
struct arg {
  int thread_index;
  uint8_t *attractors_buf, *convergence_buf;
  const double *root_reals, *root_imags;
  const complex double *roots;
  const struct cfg *cfg;
};

int parse_int_or_fail(const char *s, const char *ty) {
    char *end = NULL;
    int val = strtol(s, &end, 10);
    if (val == 0 && s == end) {
      fprintf(stderr, "kind %s: expected int but got `%s`\n", ty, s);
      exit(EXIT_FAILURE);
    }
    return val;
}

FILE *create_ppm(const char *type, const struct cfg *cfg) {
  char filename[64];
  size_t wrote;

  wrote = snprintf(filename, 64, "newton_%s_x%d.ppm", type, cfg->degree);
  assert(wrote < 64);
  FILE *f = fopen(filename, "w");
  if (!f) {
    fprintf(stderr, "failed to open `%s`\n", filename);
    exit(EXIT_FAILURE);
  }
  int max_color_val = 255;
  fprintf(f, "P3\n%d %d\n%d\n", cfg->lines, cfg->lines, max_color_val);
  return f;
}

static inline complex double our_cpow(complex double x, int degree) {
  complex double x2 = x * x, x4 = x2 * x2;
  switch (degree) {
    case 0: return 1.0;
    case 1: return x;
    case 2: return x2;
    case 3: return x2 * x;
    case 4: return x4;
    case 5: return x4 * x;
    case 6: return x4 * x2;
    case 7: return x4 * x2 * x;
    case 8: return x4 * x4;
    // know statically that d <= 9, and we always pass d-1 to this function
    default:
      abort();
  }
}
static inline double norm_squared(complex double x) {
  return creal(x)*creal(x)+cimag(x)*cimag(x);
}

void generate_roots(complex double *roots, int degree) {
  complex double r = cexp(2.*M_PI*I/((double)degree));
  complex double cur = 1.0;
  for (int i = 0; i < degree; i++) {
    roots[i] = cur;
    cur *= r;
  }
}

enum special_roots {
  NO_CONVERGENCE = 0xff,
  ZERO = 0xfe,
  TOOLARGE = 0xfd,
};

#define USE_AVX512

void find_root_predefined(complex double x0, int degree, uint8_t *restrict iter_greyscale, uint8_t *restrict attractor, const double *restrict root_reals, const double *restrict root_imags) {
  double d = (double)degree;
  double one_over_d = 1./d;
  double dm1_over_d = (d-1.)/d;
  complex double xn = x0;

  uint8_t n;
  *attractor = NO_CONVERGENCE;
  for (n = 0; n < 50; n++) {
    double xn_nsq = norm_squared(xn);
    // too close to the origin or appears to be diverging
    if (xn_nsq < 1e-6) { *attractor = ZERO; break; }
    if (xn_nsq > 1e10) { *attractor = TOOLARGE; break; }

    // actual root!
    if (xn_nsq > 0.998001 && xn_nsq < 1.002001) {
      uint8_t root_idx = NO_CONVERGENCE;
#ifdef USE_AVX512
        if (degree <= 8) {
        // xn^2 + 1 - 2 re1*re2 - 2 im1*im2 <? 1e-6
        // <=>
        // xn^2 + 1 - 1e6 <? 2 (re1*re2+im1*im2)
        // <=>
        // 0.5*(xn^2+1-1e6) <? (re1*re2+im1*im2)
        //__m512d lhs = _mm512_set1_pd(0.5*(xn_nsq+1-1e6));
        __m512d lhs = _mm512_set1_pd(-0.5*(xn_nsq+1));
        __m512d re1 = _mm512_set1_pd(creal(xn));
        __m512d im1 = _mm512_set1_pd(cimag(xn));
        __m512d re2 = _mm512_load_pd(root_reals);
        __m512d im2 = _mm512_load_pd(root_imags);
        __m512d rere = _mm512_fmadd_pd(re1,re2,lhs);
        __m512d rere_plus_imim = _mm512_fmadd_pd(im1,im2,rere);
        __m512d thresh = _mm512_set1_pd(-1e-6);
        //__m512d rere_plus_imim = _mm512_fmadd_pd(im1,im2,rere);
        //__mmask8 mask = _mm512_cmp_pd_mask(lhs, rere_plus_imim, _CMP_LT_OS);
        __mmask8 mask = _mm512_cmp_pd_mask(rere_plus_imim, thresh, _CMP_GT_OS);
        uint8_t actual_mask = (uint8_t)mask & ((1<<degree)-1);
        if (actual_mask == 0) {
          // no matching root
          root_idx = NO_CONVERGENCE;
        } else {
          root_idx = __tzcnt_u32(actual_mask);
        }
      } else {
#endif
        for (int ridx = 0; ridx < degree; ridx++) {
          double dist = xn_nsq + 1. - 2.*(creal(xn)*root_reals[ridx]+cimag(xn)*root_imags[ridx]);
          //printf("root: %lf + %lf i\n", creal(root), cimag(root));
          if (dist < 1e-6) {
            root_idx = ridx;
            break;
          }
        }
#ifdef USE_AVX512
      }
#endif
      if (root_idx != NO_CONVERGENCE) {
        *attractor = root_idx;
        break;
      }
    }
    
    double inv_nsq = 1. /xn_nsq;
    complex double w = CMPLX(creal(xn)* inv_nsq, -cimag(xn) * inv_nsq);

    xn = xn*dm1_over_d + one_over_d * our_cpow(w, degree-1);
    //complex double xn_pow_dm1 = our_cpow(xn, degree-1);
    /*if (degree == 7) {
      double norm_exp6 = xn_nsq*xn_nsq*xn_nsq;
      xn = xn*dm1_over_d + one_over_d*conj(xn_pow_dm1)/norm_exp6;
    } else {*/
    //xn = xn*dm1_over_d + one_over_d/xn_pow_dm1;
    //}
  }
  *iter_greyscale = 5*n;
}

void rgb_from_complex(complex double num, uint8_t *rgb) {
  // https://en.wikipedia.org/wiki/HSL_and_HSV#Color_conversion_formulae
  //double hprime = carg(num) * 6.0 / M_2_PI;
  double h = carg(num);
  if (h < 0) h += 2.0 * M_PI;
  double hprime = h * 3.0 / M_PI;
  //double lightness = 255. * (log(cabs(num))-log(1e-3))/log(50.);
  //double saturation = 1.0;
  //double chroma = (1.-fabs(2.*lightness-1.));//*saturation;
  //double m = lightness - 0.5*chroma;
  //double x = chroma*(1.-fabs(remainder(hprime, 2.) - 1.));
  double x = 1.0 - fabs(fmod(hprime, 2.0) - 1.0);
  //double r = m, g = m, b = m;
  double r = 0, g = 0, b = 0;

  if      (hprime < 1.) { r = 1; g = x; }       //1 = chroma from old ed.
  else if (hprime < 2.) { r = x; g = 1; }
  else if (hprime < 3.) { g = 1; b = x; }
  else if (hprime < 4.) { g = x; b = 1; }
  else if (hprime < 5.) { r = x; b = 1; }
  else                  { r = 1; b = x; }

  rgb[0] = (uint8_t)(255.0 * r);
  rgb[1] = (uint8_t)(255.0 * g);
  rgb[2] = (uint8_t)(255.0 * b);
/*  rgb[0] = (uint8_t)r;
  rgb[1] = (uint8_t)g;
  rgb[2] = (uint8_t)b;*/
}

int thread_start(void *arg_raw) {
  struct arg arg = *(struct arg *)arg_raw;
  struct cfg cfg = *arg.cfg;
  printf("thread %d started\n", arg.thread_index);

  //struct timespec t1, t2;
  //clock_gettime(CLOCK_MONOTONIC, &t1);

  int irow;
  while ((irow = atomic_fetch_add_explicit(&next_row, 1, memory_order_relaxed)) < cfg.lines) {
    size_t row = irow;
    double imag = 2.0 - 4.0 * (double)row/(double)(cfg.lines);

    for (size_t col = 0; col < cfg.lines; col++) {
      size_t buf_idx = row * cfg.lines + col;
      double real = -2.0 + 4.0 * (double)col/(double)(cfg.lines);

      complex double x0 = CMPLX(real, imag);
      find_root_predefined(x0, cfg.degree, &arg.convergence_buf[buf_idx], &arg.attractors_buf[buf_idx], arg.root_reals, arg.root_imags);
    }
    atomic_store_explicit(&row_done[row], 1, memory_order_release);
  }
  //clock_gettime(CLOCK_MONOTONIC, &t2);

  //uint64_t millis1 = t1.tv_sec * 1000 + t1.tv_nsec / 1000000;
  //uint64_t millis2 = t2.tv_sec * 1000 + t2.tv_nsec / 1000000;
  //uint64_t delta = millis2 - millis1;
  //printf("thread %d took %lld ms\n", arg.thread_index, (unsigned long long)delta);

  return 0;
}

void faster_snprintf(char *dst, uint8_t r, uint8_t g, uint8_t b) {
  dst[0] = '0'+r/100;
  dst[1] = '0'+(r/10)%10;
  dst[2] = '0'+r%10;
  dst[3] = ' ';

  dst[4] = '0'+g/100;
  dst[5] = '0'+(g/10)%10;
  dst[6] = '0'+g%10;
  dst[7] = ' ';

  dst[8] = '0'+b/100;
  dst[9] = '0'+(b/10)%10;
  dst[10] = '0'+b%10;
  dst[11] = '\n';
}

#define OUTBUF_SIZE 12*4096

int main(int argc, const char *argv[]) {
  /*
  cpu_set_t *s = CPU_ALLOC(CPU_SETSIZE);
  for (int i = 0; i <= 112; i++) {
    if (i % 2 == 0) {
      CPU_SET(i, s);
    } else {
      CPU_CLR(i, s);
    }
  }
  pthread_setaffinity_np(pthread_self(), CPU_SETSIZE, s);
  CPU_FREE(s);
  */

  struct cfg cfg = (struct cfg){
    .num_threads = 1,
    .lines = 1000,
    .degree = 3
  };

  for (int i = 1; i < argc; i++) {
    const char *arg = argv[i];
    if (arg[0] == '-') {
      // option
      if (arg[1] == 't') {
        cfg.num_threads = parse_int_or_fail(&arg[2], "num_threads");
      } else if (arg[1] == 'l') {
        cfg.lines = parse_int_or_fail(&arg[2], "lines");
      }
    } else {
      // only non-option arg is the polynomial degree
      cfg.degree = parse_int_or_fail(arg, "degree");
    }
  }

  printf("%d threads, %dx%d image, degree %d\n", cfg.num_threads, cfg.lines, cfg.lines, cfg.degree);
  assert(cfg.degree > 0); assert(cfg.degree <= 9);
  assert(cfg.lines < 10000);

  complex double roots[10] = { 0 };
  double *root_reals = aligned_alloc(64, 10*sizeof(double));
  double *root_imags = aligned_alloc(64, 10*sizeof(double));
  generate_roots(roots, cfg.degree);

  uint8_t roots_rgb[30];
  for (int i = 0; i < 10; i++) {
    root_reals[i] = creal(roots[i]);
    root_imags[i] = cimag(roots[i]);
    rgb_from_complex(roots[i], &roots_rgb[3*i]);
  }

  uint8_t *attractors_buf = malloc(cfg.lines * cfg.lines * sizeof(uint8_t));
  uint8_t *convergences_buf = malloc(cfg.lines * cfg.lines * sizeof(uint8_t));
  if (!attractors_buf || !convergences_buf) {
    return EXIT_FAILURE;
  }

  FILE *f_attr = create_ppm("attractors", &cfg);
  FILE *f_conv = create_ppm("convergence", &cfg);

  thrd_t *threads = malloc(cfg.num_threads * sizeof(thrd_t));
  assert(threads);
  struct arg *args = malloc(cfg.num_threads * sizeof(struct arg));

  atomic_init(&next_row, 0);

  row_done = calloc(cfg.lines, sizeof(atomic_uchar));
  assert(row_done);
  for (int i = 0; i < cfg.num_threads; i++) {
    args[i] = (struct arg) {
      .attractors_buf = attractors_buf,
      .convergence_buf = convergences_buf,
      .thread_index = i,
      .roots = roots,
      .root_reals = root_reals,
      .root_imags = root_imags,
      .cfg = &cfg
    };
    thrd_create(&threads[i], thread_start, &args[i]);
  }
  char *conv_buf = malloc(OUTBUF_SIZE);
  char *attr_buf = malloc(OUTBUF_SIZE);
  if (!conv_buf || !attr_buf) {
    exit(EXIT_FAILURE);
  }
/*
  for (int i = 0; i < cfg.num_threads; i++) {
    int res;
    int sts = thrd_join(threads[i], &res);
    assert(sts == thrd_success);
  }
  for (int i = 0; i < cfg.lines; i++) {
    assert(mtx_trylock(&mutexes[i]) != thrd_success);
    mtx_destroy(&mutexes[i]);
  }

  free(threads);
  free(args);
  free(mutexes);*/

  size_t conv_len = 0;
  size_t attr_len = 0;

  for (size_t r = 0; r < cfg.lines; r++) {
    while (!atomic_load_explicit(&row_done[r], memory_order_acquire))
      thrd_yield();
    for (size_t c = 0; c < cfg.lines; c++) {
      size_t buf_idx = cfg.lines*r+c;
      uint8_t grey = convergences_buf[buf_idx];
      if (conv_len + 12 >= OUTBUF_SIZE) {
        fwrite(conv_buf, 1, conv_len, f_conv);
        conv_len = 0;
      }
      uint8_t white3[3] = {255, 255, 255};
      uint8_t grey3[3] = {128, 128, 128};
      uint8_t black3[3] = {0, 0, 0};

      faster_snprintf(&conv_buf[conv_len], grey, grey, grey);
      //snprintf(&conv_buf[conv_len], 12, "%03d %03d %03d\n", grey, grey, grey);
      conv_len += 12;
      uint8_t attractor = attractors_buf[buf_idx];
      uint8_t *rgb;
      if (attractor == TOOLARGE) {
        rgb = white3;
      } else if (attractor == ZERO) {
        rgb = black3;
      } else if (attractor == NO_CONVERGENCE) {
        rgb = grey3;
      } else {
        rgb = &roots_rgb[3 *  attractor];
      }
      if (attr_len + 12 >= OUTBUF_SIZE) {
        fwrite(attr_buf, 1, attr_len, f_attr);
        attr_len = 0;
      }
      //snprintf(&attr_buf[attr_len], 12, "%03d %03d %03d\n", rgb[0], rgb[1], rgb[2]);
      faster_snprintf(&attr_buf[attr_len], rgb[0], rgb[1], rgb[2]);
      attr_len += 12;
    }
  }
  if (conv_len > 0) {
    fwrite(conv_buf, 1, conv_len, f_conv);
  }
  if (attr_len > 0) {
    fwrite(attr_buf, 1, attr_len, f_attr);
  }  
  for (int i = 0; i < cfg.num_threads; i++) {
    int res;
    int sts = thrd_join(threads[i], &res);
    assert(sts == thrd_success);
  }

  free(threads);
  free(args);

  free(conv_buf);
  free(attr_buf);

  fclose(f_conv);
  fclose(f_attr);
  free((void *)row_done);
}
